
import { useState, useCallback } from 'react';
import { Color } from '../types';
import { rgbToHex, generateComplementaryColors } from '../utils/colorUtils';

interface UseColorExtractorReturn {
  extractColors: (imageUrl: string) => Promise<Color[]>;
  isExtracting: boolean;
  error: string | null;
}

const useColorExtractor = (): UseColorExtractorReturn => {
  const [isExtracting, setIsExtracting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const extractColors = useCallback(async (imageUrl: string): Promise<Color[]> => {
    setIsExtracting(true);
    setError(null);

    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'Anonymous';
      
      img.onload = () => {
        try {
          // Create canvas and draw image
          const canvas = document.createElement('canvas');
          const context = canvas.getContext('2d');
          
          if (!context) {
            setIsExtracting(false);
            setError('Canvas context not supported');
            reject(new Error('Canvas context not supported'));
            return;
          }
          
          // Set canvas size to image size
          canvas.width = img.width;
          canvas.height = img.height;
          
          // Draw image on canvas
          context.drawImage(img, 0, 0);
          
          // Get image data
          const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
          const data = imageData.data;
          
          // Create a map for counting color occurrences
          const colorCounts: Record<string, number> = {};
          
          // Sample pixels (for performance, we don't check every pixel)
          const sampleInterval = Math.max(1, Math.floor(data.length / 4 / 10000));
          
          for (let i = 0; i < data.length; i += 4 * sampleInterval) {
            const r = data[i];
            const g = data[i + 1];
            const b = data[i + 2];
            
            // Skip transparent pixels
            if (data[i + 3] < 128) continue;
            
            // Quantize colors to reduce similar colors
            const quantizedR = Math.round(r / 16) * 16;
            const quantizedG = Math.round(g / 16) * 16;
            const quantizedB = Math.round(b / 16) * 16;
            
            const hex = rgbToHex(quantizedR, quantizedG, quantizedB);
            
            colorCounts[hex] = (colorCounts[hex] || 0) + 1;
          }
          
          // Sort colors by occurrence
          const sortedColors = Object.entries(colorCounts)
            .sort((a, b) => b[1] - a[1])
            .map(([hex]) => ({
              hex,
              rgb: {
                r: parseInt(hex.substring(1, 3), 16),
                g: parseInt(hex.substring(3, 5), 16),
                b: parseInt(hex.substring(5, 7), 16)
              }
            }));
          
          // Take top 6 colors
          const dominantColors = sortedColors.slice(0, 6);
          
          // If we have a dominant color, generate complementary colors
          if (dominantColors.length > 0) {
            const generatedColors = generateComplementaryColors(dominantColors[0].hex);
            const result = [...dominantColors, ...generatedColors.slice(1)]
              // Remove duplicates
              .filter((color, index, self) => 
                index === self.findIndex(c => c.hex === color.hex)
              )
              // Take top 6
              .slice(0, 6);
            
            setIsExtracting(false);
            resolve(result);
          } else {
            // Fallback if no colors were found
            setIsExtracting(false);
            setError('Could not extract colors from image');
            reject(new Error('Could not extract colors from image'));
          }
        } catch (err) {
          setIsExtracting(false);
          setError(err instanceof Error ? err.message : 'Unknown error occurred');
          reject(err);
        }
      };
      
      img.onerror = (err) => {
        setIsExtracting(false);
        setError('Failed to load image');
        reject(new Error('Failed to load image'));
      };
      
      img.src = imageUrl;
    });
  }, []);

  return { extractColors, isExtracting, error };
};

export default useColorExtractor;
