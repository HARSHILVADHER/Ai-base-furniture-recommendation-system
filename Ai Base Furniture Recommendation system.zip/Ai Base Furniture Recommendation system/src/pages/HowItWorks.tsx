import React from 'react';
import Navigation from '../components/Navigation';
import { UploadCloud, Palette, Move, Zap, PlusSquare } from 'lucide-react';

const HowItWorks: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="container mx-auto py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-center mb-8">How It Works</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center mb-4">
                <div className="bg-brand-purple/10 p-3 rounded-full mr-4">
                  <UploadCloud className="h-6 w-6 text-brand-purple" />
                </div>
                <h2 className="text-xl font-semibold">1. Upload Your Room</h2>
              </div>
              <p className="text-gray-600">
                Start by uploading a photo of your room. Our application will automatically analyze the image and identify areas where furniture can be placed.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center mb-4">
                <div className="bg-brand-purple/10 p-3 rounded-full mr-4">
                  <Palette className="h-6 w-6 text-brand-purple" />
                </div>
                <h2 className="text-xl font-semibold">2. Choose Your Colors</h2>
              </div>
              <p className="text-gray-600">
                Select colors from the extracted color palette or choose custom colors to match your design preferences. These colors will be applied to the 3D furniture models.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center mb-4">
                <div className="bg-brand-purple/10 p-3 rounded-full mr-4">
                  <Move className="h-6 w-6 text-brand-purple" />
                </div>
                <h2 className="text-xl font-semibold">3. Place Furniture</h2>
              </div>
              <p className="text-gray-600">
                Drag and drop furniture models onto your room image. You can add placement points anywhere in the image and then place 3D furniture models on these points.
              </p>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center mb-4">
                <div className="bg-brand-purple/10 p-3 rounded-full mr-4">
                  <Zap className="h-6 w-6 text-brand-purple" />
                </div>
                <h2 className="text-xl font-semibold">4. Customize Your Design</h2>
              </div>
              <p className="text-gray-600">
                Adjust the size, position, and colors of your furniture models to create the perfect room design. You can also create a full 3D room model with custom dimensions.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 mt-8">
            <h2 className="text-xl font-semibold mb-4">Try the 3D Room Creator</h2>
            <p className="text-gray-600 mb-4">
              Want to create a complete 3D model of your room from scratch? Use our 3D Room Creator to define room dimensions and add furniture models in a fully customizable 3D environment.
            </p>
            <div className="flex justify-center">
              <a href="/create-room" className="inline-flex items-center px-4 py-2 bg-brand-purple text-white rounded-md hover:bg-brand-purple/90 transition-colors">
                <PlusSquare className="mr-2 h-4 w-4" />
                <span>Create 3D Room</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HowItWorks;
