
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Canvas } from '@react-three/fiber';
import { PresentationControls, Environment, OrbitControls } from '@react-three/drei';
import { HexColorPicker } from "react-colorful";
import { FurnitureModel, Color } from '../types';
import { Sofa, Chair, Table, Lamp, Bed } from '../components/FurnitureModels';
import Navigation from '../components/Navigation';
import * as THREE from 'three';
import { useToast } from "@/components/ui/use-toast";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import ImageUploader from "@/components/ImageUploader";

// Type definitions that were missing
interface RoomDimensions {
  width: number;
  length: number;
  height: number;
}

interface PlacedFurniture {
  id: string;
  modelId: string;
  position: [number, number, number];
  rotation: [number, number, number];
  color: string;
  scale: number;
}

// Sample furniture models
const sampleFurnitureModels: FurnitureModel[] = [
  { id: 'sofa-1', name: 'Sofa', type: 'sofa', previewImage: '' },
  { id: 'chair-1', name: 'Chair', type: 'chair', previewImage: '' },
  { id: 'table-1', name: 'Coffee Table', type: 'table', previewImage: '' },
  { id: 'bed-1', name: 'Bed', type: 'bed', previewImage: '' },
  { id: 'lamp-1', name: 'Floor Lamp', type: 'lamp', previewImage: '' }
];

const CreateRoom: React.FC = () => {
  const [roomDimensions, setRoomDimensions] = useState<RoomDimensions>({
    width: 10,
    length: 10,
    height: 3
  });
  
  const [wallColor, setWallColor] = useState('#FFFFFF');
  const [floorColor, setFloorColor] = useState('#8B4513');
  const [selectedTab, setSelectedTab] = useState('room');
  const [placedFurniture, setPlacedFurniture] = useState<PlacedFurniture[]>([]);
  const [selectedFurniture, setSelectedFurniture] = useState<string | null>(null);
  const [selectedFurnitureColor, setSelectedFurnitureColor] = useState('#8B5CF6');
  const [showColorPicker, setShowColorPicker] = useState<'wall' | 'floor' | 'furniture' | null>(null);
  const [selectedWall, setSelectedWall] = useState<'back' | 'left' | 'right' | null>(null);
  const [wallImages, setWallImages] = useState<{
    back?: string;
    left?: string;
    right?: string;
  }>({});
  const { toast } = useToast();

  const handleImageUpload = (file: File, imageUrl: string) => {
    if (!selectedWall) {
      toast({
        title: "No wall selected",
        description: "Please select a wall first before uploading an image.",
        variant: "destructive"
      });
      return;
    }

    setWallImages(prev => ({
      ...prev,
      [selectedWall]: imageUrl
    }));

    toast({
      title: "Image uploaded",
      description: "The image has been successfully added to the wall.",
    });
  };

  const handleDimensionChange = (dimension: keyof RoomDimensions, value: string) => {
    const numValue = parseFloat(value);
    if (!isNaN(numValue) && numValue > 0) {
      setRoomDimensions(prev => ({
        ...prev,
        [dimension]: numValue
      }));
    }
  };

  const handleAddFurniture = (modelId: string) => {
    const offset = placedFurniture.length * 0.5;
    const newFurniture: PlacedFurniture = {
      id: `furniture-${Date.now()}`,
      modelId,
      position: [offset, 0, offset],
      rotation: [0, 0, 0],
      color: selectedFurnitureColor,
      scale: 1.0
    };
    setPlacedFurniture(prev => [...prev, newFurniture]);
    setSelectedFurniture(newFurniture.id);
    toast({
      title: "Furniture added",
      description: "New furniture has been added to the room.",
    });
  };

  const handleUpdateFurniture = (id: string, updates: Partial<PlacedFurniture>) => {
    setPlacedFurniture(prev => 
      prev.map(item => 
        item.id === id ? { ...item, ...updates } : item
      )
    );
  };

  const handleRemoveFurniture = (id: string) => {
    setPlacedFurniture(prev => prev.filter(item => item.id !== id));
    if (selectedFurniture === id) {
      setSelectedFurniture(null);
    }

    toast({
      title: "Furniture removed",
      description: "The furniture has been removed from the room.",
    });
  };

  const selectedFurnitureItem = selectedFurniture 
    ? placedFurniture.find(item => item.id === selectedFurniture) 
    : null;

  const generateCircularPalette = () => {
    const colors: Color[] = [];
    for (let i = 0; i < 24; i++) {
      const hue = (i * 15) % 360;
      const color = `hsl(${hue}, 70%, 60%)`;
      colors.push({
        hex: color,
        rgb: { r: 0, g: 0, b: 0 }
      });
    }
    return colors;
  };

  const circularColors = generateCircularPalette();

  const Room: React.FC<{
    dimensions: RoomDimensions;
    wallColor: string;
    floorColor: string;
    placedFurniture: PlacedFurniture[];
    onSelectFurniture: (id: string | null) => void;
  }> = ({ dimensions, wallColor, floorColor, placedFurniture, onSelectFurniture }) => {
    const { width, length, height } = dimensions;
    
    return (
      <group onClick={(e) => {
        e.stopPropagation();
        onSelectFurniture(null);
      }}>
        <mesh 
          rotation={[-Math.PI / 2, 0, 0]} 
          position={[0, 0, 0]} 
          receiveShadow
        >
          <planeGeometry args={[width, length]} />
          <meshStandardMaterial color={floorColor} roughness={0.8} />
        </mesh>
        
        <mesh 
          position={[0, height / 2, -length / 2]} 
          receiveShadow
          onClick={(e) => {
            e.stopPropagation();
            setSelectedWall('back');
          }}
        >
          <planeGeometry args={[width, height]} />
          <meshStandardMaterial 
            color={selectedWall === 'back' ? '#8B5CF6' : wallColor} 
            map={wallImages.back ? new THREE.TextureLoader().load(wallImages.back) : null}
            roughness={0.8} 
          />
        </mesh>
        
        <mesh 
          position={[-width / 2, height / 2, 0]} 
          rotation={[0, Math.PI / 2, 0]} 
          receiveShadow
          onClick={(e) => {
            e.stopPropagation();
            setSelectedWall('left');
          }}
        >
          <planeGeometry args={[length, height]} />
          <meshStandardMaterial 
            color={selectedWall === 'left' ? '#8B5CF6' : wallColor}
            map={wallImages.left ? new THREE.TextureLoader().load(wallImages.left) : null}
            roughness={0.8} 
          />
        </mesh>
        
        <mesh 
          position={[width / 2, height / 2, 0]} 
          rotation={[0, -Math.PI / 2, 0]} 
          receiveShadow
          onClick={(e) => {
            e.stopPropagation();
            setSelectedWall('right');
          }}
        >
          <planeGeometry args={[length, height]} />
          <meshStandardMaterial 
            color={selectedWall === 'right' ? '#8B5CF6' : wallColor}
            map={wallImages.right ? new THREE.TextureLoader().load(wallImages.right) : null}
            roughness={0.8} 
          />
        </mesh>
        
        {placedFurniture.map((item) => {
          const model = sampleFurnitureModels.find(m => m.id === item.modelId);
          if (!model) return null;
          
          return (
            <group 
              key={item.id}
              position={item.position}
              rotation={item.rotation as any}
              scale={[item.scale, item.scale, item.scale]}
              onClick={(e) => {
                e.stopPropagation();
                onSelectFurniture(item.id);
              }}
            >
              {model.type === 'sofa' && <Sofa color={item.color} />}
              {model.type === 'chair' && <Chair color={item.color} />}
              {model.type === 'table' && <Table color={item.color} />}
              {model.type === 'lamp' && <Lamp color={item.color} />}
              {model.type === 'bed' && <Bed color={item.color} />}
            </group>
          );
        })}
      </group>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <div className="container mx-auto py-8 px-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-4">Room Designer</h2>
              
              <Tabs value={selectedTab} onValueChange={setSelectedTab}>
                <TabsList className="grid grid-cols-3 mb-4">
                  <TabsTrigger value="room">Room</TabsTrigger>
                  <TabsTrigger value="furniture">Furniture</TabsTrigger>
                  <TabsTrigger value="colors">Colors</TabsTrigger>
                </TabsList>
                
                <TabsContent value="room" className="space-y-4">
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg bg-gray-50">
                      <h3 className="font-medium mb-2">Wall Selection & Image Upload</h3>
                      <p className="text-sm text-gray-500 mb-4">
                        1. Click on a wall in the room to select it
                        <br />
                        2. Upload an image to apply to the selected wall
                      </p>
                      {selectedWall ? (
                        <>
                          <p className="text-sm font-medium mb-2">
                            Selected Wall: {selectedWall.charAt(0).toUpperCase() + selectedWall.slice(1)}
                          </p>
                          <ImageUploader onImageUpload={handleImageUpload} />
                        </>
                      ) : (
                        <p className="text-sm text-brand-purple">Click a wall to select it</p>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="width">Width (m)</Label>
                    <Input 
                      id="width"
                      type="number" 
                      min="1"
                      step="0.1"
                      value={roomDimensions.width} 
                      onChange={(e) => handleDimensionChange('width', e.target.value)}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="length">Length (m)</Label>
                    <Input 
                      id="length"
                      type="number" 
                      min="1"
                      step="0.1"
                      value={roomDimensions.length} 
                      onChange={(e) => handleDimensionChange('length', e.target.value)}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="height">Height (m)</Label>
                    <Input 
                      id="height"
                      type="number" 
                      min="1"
                      step="0.1"
                      value={roomDimensions.height} 
                      onChange={(e) => handleDimensionChange('height', e.target.value)}
                    />
                  </div>
                </TabsContent>
                
                <TabsContent value="furniture" className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    {sampleFurnitureModels.map(model => (
                      <Button 
                        key={model.id}
                        variant="outline"
                        className="h-auto py-3 justify-start"
                        onClick={() => handleAddFurniture(model.id)}
                      >
                        <span className="text-left">{model.name}</span>
                      </Button>
                    ))}
                  </div>
                  
                  {selectedFurnitureItem && (
                    <div className="mt-6 border-t pt-4">
                      <h3 className="font-medium mb-2">Selected Item</h3>
                      
                      <div className="space-y-3">
                        <div>
                          <Label>Position X</Label>
                          <Input 
                            type="range" 
                            min={-roomDimensions.width/2 + 1} 
                            max={roomDimensions.width/2 - 1} 
                            step="0.1"
                            value={selectedFurnitureItem.position[0]}
                            onChange={(e) => {
                              const newPosition = [...selectedFurnitureItem.position];
                              newPosition[0] = parseFloat(e.target.value);
                              handleUpdateFurniture(selectedFurnitureItem.id, {
                                position: newPosition as [number, number, number]
                              });
                            }}
                          />
                        </div>
                        
                        <div>
                          <Label>Position Z</Label>
                          <Input 
                            type="range" 
                            min={-roomDimensions.length/2 + 1} 
                            max={roomDimensions.length/2 - 1} 
                            step="0.1"
                            value={selectedFurnitureItem.position[2]}
                            onChange={(e) => {
                              const newPosition = [...selectedFurnitureItem.position];
                              newPosition[2] = parseFloat(e.target.value);
                              handleUpdateFurniture(selectedFurnitureItem.id, {
                                position: newPosition as [number, number, number]
                              });
                            }}
                          />
                        </div>
                        
                        <div>
                          <Label>Rotation</Label>
                          <Input 
                            type="range" 
                            min="0" 
                            max={Math.PI * 2} 
                            step="0.1"
                            value={selectedFurnitureItem.rotation[1]}
                            onChange={(e) => {
                              const newRotation = [...selectedFurnitureItem.rotation];
                              newRotation[1] = parseFloat(e.target.value);
                              handleUpdateFurniture(selectedFurnitureItem.id, {
                                rotation: newRotation as [number, number, number]
                              });
                            }}
                          />
                        </div>
                        
                        <div>
                          <Label>Scale</Label>
                          <Input 
                            type="range" 
                            min="0.5" 
                            max="2" 
                            step="0.1"
                            value={selectedFurnitureItem.scale}
                            onChange={(e) => {
                              handleUpdateFurniture(selectedFurnitureItem.id, {
                                scale: parseFloat(e.target.value)
                              });
                            }}
                          />
                        </div>
                        
                        <div className="flex items-center space-x-2 mt-4">
                          <Popover>
                            <PopoverTrigger asChild>
                              <div 
                                className="w-8 h-8 rounded-full border cursor-pointer shadow-md" 
                                style={{ backgroundColor: selectedFurnitureItem.color }}
                              />
                            </PopoverTrigger>
                            <PopoverContent className="w-64 p-3">
                              <div className="space-y-3">
                                <h4 className="font-medium text-sm">Select Color</h4>
                                <div className="circular-color-palette">
                                  <div className="flex flex-wrap gap-2 justify-center">
                                    {circularColors.map((color, index) => (
                                      <div
                                        key={index}
                                        className="w-8 h-8 rounded-full cursor-pointer hover:scale-110 transition-transform shadow-sm"
                                        style={{ backgroundColor: color.hex }}
                                        onClick={() => {
                                          handleUpdateFurniture(selectedFurnitureItem.id, { color: color.hex });
                                          setSelectedFurnitureColor(color.hex);
                                        }}
                                      />
                                    ))}
                                  </div>
                                  <div className="mt-3">
                                    <Label>Custom Color</Label>
                                    <HexColorPicker 
                                      color={selectedFurnitureItem.color}
                                      onChange={(color) => {
                                        handleUpdateFurniture(selectedFurnitureItem.id, { color });
                                        setSelectedFurnitureColor(color);
                                      }}
                                      className="w-full max-w-[240px] mt-2"
                                    />
                                  </div>
                                </div>
                              </div>
                            </PopoverContent>
                          </Popover>
                          <Button 
                            variant="destructive" 
                            onClick={() => handleRemoveFurniture(selectedFurnitureItem.id)}
                          >
                            Remove
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="colors" className="space-y-4">
                  <div>
                    <Label>Wall Color</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <div className="flex items-center space-x-2 mt-2">
                          <div 
                            className="w-8 h-8 rounded-full border cursor-pointer shadow-md" 
                            style={{ backgroundColor: wallColor }}
                          />
                          <span className="text-sm">{wallColor}</span>
                        </div>
                      </PopoverTrigger>
                      <PopoverContent className="w-64 p-3">
                        <div className="space-y-3">
                          <h4 className="font-medium text-sm">Select Wall Color</h4>
                          <div className="circular-color-palette">
                            <div className="flex flex-wrap gap-2 justify-center">
                              {circularColors.map((color, index) => (
                                <div
                                  key={index}
                                  className="w-8 h-8 rounded-full cursor-pointer hover:scale-110 transition-transform shadow-sm"
                                  style={{ backgroundColor: color.hex }}
                                  onClick={() => setWallColor(color.hex)}
                                />
                              ))}
                            </div>
                            <div className="mt-3">
                              <HexColorPicker 
                                color={wallColor}
                                onChange={setWallColor}
                                className="w-full max-w-[240px] mt-2"
                              />
                            </div>
                          </div>
                        </div>
                      </PopoverContent>
                    </Popover>
                  </div>
                  
                  <div>
                    <Label>Floor Color</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <div className="flex items-center space-x-2 mt-2">
                          <div 
                            className="w-8 h-8 rounded-full border cursor-pointer shadow-md" 
                            style={{ backgroundColor: floorColor }}
                          />
                          <span className="text-sm">{floorColor}</span>
                        </div>
                      </PopoverTrigger>
                      <PopoverContent className="w-64 p-3">
                        <div className="space-y-3">
                          <h4 className="font-medium text-sm">Select Floor Color</h4>
                          <div className="circular-color-palette">
                            <div className="flex flex-wrap gap-2 justify-center">
                              {circularColors.map((color, index) => (
                                <div
                                  key={index}
                                  className="w-8 h-8 rounded-full cursor-pointer hover:scale-110 transition-transform shadow-sm"
                                  style={{ backgroundColor: color.hex }}
                                  onClick={() => setFloorColor(color.hex)}
                                />
                              ))}
                            </div>
                            <div className="mt-3">
                              <HexColorPicker 
                                color={floorColor}
                                onChange={setFloorColor}
                                className="w-full max-w-[240px] mt-2"
                              />
                            </div>
                          </div>
                        </div>
                      </PopoverContent>
                    </Popover>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
          
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md" style={{ height: '70vh' }}>
              <Canvas 
                shadows 
                camera={{ position: [0, 5, 8], fov: 50 }}
                onCreated={({ gl }) => {
                  gl.shadowMap.enabled = true;
                  gl.shadowMap.type = THREE.PCFSoftShadowMap;
                }}
              >
                <ambientLight intensity={0.5} />
                <spotLight position={[0, 10, 0]} angle={0.3} penumbra={1} intensity={1} castShadow />
                <directionalLight position={[5, 5, 5]} intensity={0.5} castShadow />
                
                <Room 
                  dimensions={roomDimensions}
                  wallColor={wallColor}
                  floorColor={floorColor}
                  placedFurniture={placedFurniture}
                  onSelectFurniture={setSelectedFurniture}
                />
                
                <OrbitControls 
                  enableZoom={true}
                  enablePan={true}
                  minPolarAngle={0}
                  maxPolarAngle={Math.PI / 2}
                />
                
                <Environment preset="apartment" />
              </Canvas>
            </div>
            
            <div className="bg-white rounded-lg shadow-md mt-4 p-4">
              <p className="text-sm text-gray-500">
                Click and drag to rotate view. Scroll to zoom. Select furniture to adjust position, rotation, and color.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateRoom;
