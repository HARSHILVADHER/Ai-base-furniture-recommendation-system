import React, { useState, useCallback, useEffect } from 'react';
import Navigation from '@/components/Navigation';
import ImageUploader from '@/components/ImageUploader';
import ImageEditor from '@/components/ImageEditor';
import ColorPalette from '@/components/ColorPalette';
import ThreeDViewer from '@/components/ThreeDViewer';
import ModelSelector from '@/components/ModelSelector';
import PlacementPoints from '@/components/PlacementPoints';
import Instructions from '@/components/Instructions';
import useColorExtractor from '@/hooks/useColorExtractor';
import { generateComplementaryColors } from '@/utils/colorUtils';
import { Color, FurnitureModel, PlacementPoint, PlacedModel } from '@/types';
import { useToast } from '@/components/ui/use-toast';

const Index = () => {
  // State
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [colors, setColors] = useState<Color[]>([]);
  const [selectedColor, setSelectedColor] = useState<Color | null>(null);
  const [draggingModel, setDraggingModel] = useState<FurnitureModel | null>(null);
  const [placementPoints, setPlacementPoints] = useState<PlacementPoint[]>([]);
  const [placedModels, setPlacedModels] = useState<PlacedModel[]>([]);
  
  // Custom hooks
  const { extractColors, isExtracting } = useColorExtractor();
  const { toast } = useToast();

  // Mock furniture models
  const [furnitureModels] = useState<Record<string, FurnitureModel>>({
    'sofa-1': { 
      id: 'sofa-1', 
      name: 'Modern Sofa', 
      type: 'sofa',
      previewImage: 'https://cdn-icons-png.flaticon.com/512/2400/2400092.png'
    },
    'chair-1': { 
      id: 'chair-1', 
      name: 'Lounge Chair', 
      type: 'chair', 
      previewImage: 'https://cdn-icons-png.flaticon.com/512/2929/2929066.png'
    },
    'table-1': { 
      id: 'table-1', 
      name: 'Coffee Table', 
      type: 'table', 
      previewImage: 'https://cdn-icons-png.flaticon.com/512/2400/2400183.png'
    },
    'bed-1': { 
      id: 'bed-1', 
      name: 'Queen Bed', 
      type: 'bed', 
      previewImage: 'https://cdn-icons-png.flaticon.com/512/2400/2400044.png'
    },
    'lamp-1': { 
      id: 'lamp-1', 
      name: 'Floor Lamp', 
      type: 'lamp', 
      previewImage: 'https://cdn-icons-png.flaticon.com/512/5266/5266649.png'
    },
  });

  // Handle image upload
  const handleImageUpload = useCallback(async (file: File, url: string) => {
    setImageFile(file);
    setImageUrl(url);
    
    try {
      // Extract colors from the image
      const extractedColors = await extractColors(url);
      
      setColors(extractedColors);
      setSelectedColor(extractedColors[0]);
      
      toast({
        title: "Colors extracted",
        description: "We've identified the main colors from your image",
      });
    } catch (error) {
      console.error('Color extraction failed:', error);
      toast({
        title: "Color extraction failed",
        description: "Could not extract colors from the image",
        variant: "destructive"
      });
    }
  }, [extractColors, toast]);

  // Handle color selection
  const handleColorSelect = useCallback((color: Color) => {
    setSelectedColor(color);
    
    toast({
      title: "Color selected",
      description: `Selected color: ${color.hex}`,
    });
  }, [toast]);

  // Handle color pick from image
  const handleColorPick = useCallback((color: Color) => {
    // Check if color already exists in palette
    const existingColor = colors.find(c => c.hex === color.hex);
    
    if (!existingColor) {
      // Generate complementary colors
      const generatedColors = generateComplementaryColors(color.hex);
      
      // Add to palette
      setColors(prevColors => {
        const newColors = [color, ...prevColors];
        // Keep only 6 colors
        return newColors.slice(0, 6);
      });
    }
    
    // Select the color
    setSelectedColor(color);
  }, [colors]);

  // Handle restart (upload new image)
  const handleRestart = useCallback(() => {
    setImageFile(null);
    setImageUrl(null);
    setColors([]);
    setSelectedColor(null);
    setPlacementPoints([]);
    setPlacedModels([]);
  }, []);

  // Handle drag model
  const handleDragModel = useCallback((model: FurnitureModel) => {
    setDraggingModel(model);
  }, []);

  // Add a custom placement point
  const handleAddPlacementPoint = useCallback((point: Omit<PlacementPoint, 'id'>) => {
    const newPoint: PlacementPoint = {
      ...point,
      id: `point-${Date.now()}`
    };
    
    setPlacementPoints(prev => [...prev, newPoint]);
    
    toast({
      title: "Placement point added",
      description: `You can now drag a ${point.type} to this location`
    });
  }, [toast]);

  // Handle added placed model
  const handleAddPlacedModel = useCallback((placedModel: PlacedModel) => {
    // Check if point already has a model
    const existingModel = placedModels.find(m => m.pointId === placedModel.pointId);
    
    if (existingModel) {
      // Replace the model
      setPlacedModels(prev => 
        prev.map(m => m.pointId === placedModel.pointId ? placedModel : m)
      );
    } else {
      // Add new model
      setPlacedModels(prev => [...prev, placedModel]);
    }
    
    // Update point to be filled
    setPlacementPoints(prev => 
      prev.map(p => 
        p.id === placedModel.pointId 
          ? { ...p, filled: true, modelId: placedModel.modelId } 
          : p
      )
    );
    
    toast({
      title: "Furniture placed",
      description: `${furnitureModels[placedModel.modelId].name} placed successfully`
    });
  }, [placedModels, furnitureModels, toast]);

  // Handle remove placed model
  const handleRemovePlacedModel = useCallback((modelId: string) => {
    const modelToRemove = placedModels.find(m => m.id === modelId);
    
    if (modelToRemove) {
      // Remove the model
      setPlacedModels(prev => prev.filter(m => m.id !== modelId));
      
      // Update the point to be unfilled
      setPlacementPoints(prev => 
        prev.map(p => 
          p.id === modelToRemove.pointId 
            ? { ...p, filled: false, modelId: undefined } 
            : p
        )
      );
      
      toast({
        title: "Furniture removed",
        description: "The furniture item has been removed"
      });
    }
  }, [placedModels, toast]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <header className="bg-white shadow-sm py-4">
        <div className="container px-4 md:px-6">
          <h1 className="text-3xl font-bold text-brand-purple">FurniVision 3D</h1>
          <p className="text-gray-500">Furniture Visualization</p>
        </div>
      </header>
      
      <main className="container px-4 md:px-6 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-brand-purple mb-2">Furniture Visualization</h2>
          <p className="text-gray-600">Upload an image, extract colors, and visualize your furniture in 3D</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Left Sidebar */}
          <div className="md:col-span-1 space-y-6">
            {/* Instructions */}
            <Instructions />
            
            {/* Color Palette */}
            <ColorPalette 
              colors={colors} 
              selectedColor={selectedColor} 
              onSelectColor={handleColorSelect} 
            />
            
            {/* Only show models if an image is uploaded */}
            {imageUrl && (
              <ModelSelector 
                models={Object.values(furnitureModels)} 
                selectedColor={selectedColor?.hex || '#8B5CF6'} 
                onDragModel={handleDragModel} 
              />
            )}
          </div>
          
          {/* Main Content */}
          <div className="md:col-span-2 space-y-6 flex flex-col items-center">
            {!imageUrl ? (
              <div className="w-full max-w-2xl">
                <ImageUploader onImageUpload={handleImageUpload} />
              </div>
            ) : (
              <div className="space-y-6 w-full">
                {/* Image Editor */}
                <div className="bg-white rounded-lg shadow-md p-4">
                  <h2 className="text-lg font-medium mb-4">Your Space</h2>
                  
                  {/* Show placement points component if we have an image */}
                  <PlacementPoints 
                    imageUrl={imageUrl}
                    placementPoints={placementPoints}
                    placedModels={placedModels}
                    furnitureModels={furnitureModels}
                    selectedColor={selectedColor?.hex || '#8B5CF6'}
                    onAddPlacedModel={handleAddPlacedModel}
                    onAddPlacementPoint={handleAddPlacementPoint}
                    onRemovePlacedModel={handleRemovePlacedModel}
                  />
                </div>
                
                {/* Color Picker */}
                <div className="bg-white rounded-lg shadow-md p-4">
                  <h2 className="text-lg font-medium mb-4">Pick Colors</h2>
                  <ImageEditor 
                    imageUrl={imageUrl} 
                    onColorPick={handleColorPick}
                    onRestart={handleRestart}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      
      <footer className="bg-white border-t py-6 mt-12">
        <div className="container px-4 md:px-6 text-center">
          <p className="text-gray-500">© 2025 FurniVision 3D</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
