
import React, { useState, useEffect, useCallback } from 'react';
import { Canvas } from '@react-three/fiber';
import { PresentationControls, Environment } from '@react-three/drei';
import { PlacementPoint, PlacedModel, FurnitureModel } from '../types';
import { CircleDotIcon, SquareDotIcon, CircleIcon, Plus, ZoomIn, ZoomOut, Trash } from 'lucide-react';
import * as THREE from 'three';
import { Button } from '@/components/ui/button';

interface PlacementPointsProps {
  imageUrl: string;
  placementPoints: PlacementPoint[];
  placedModels: PlacedModel[];
  furnitureModels: Record<string, FurnitureModel>;
  selectedColor: string;
  onAddPlacedModel: (placedModel: PlacedModel) => void;
  onAddPlacementPoint: (point: Omit<PlacementPoint, 'id'>) => void;
  onRemovePlacedModel: (modelId: string) => void;
}

// Simple 3D model components (same as in ThreeDViewer)
const SofaModel = ({ color }: { color: string }) => (
  <group>
    <mesh position={[0, -0.2, 0]} castShadow>
      <boxGeometry args={[2, 0.4, 1]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 0.4, -0.5]} castShadow>
      <boxGeometry args={[2, 0.8, 0.2]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[-0.9, 0.2, 0.3]} castShadow>
      <boxGeometry args={[0.2, 0.4, 0.6]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0.9, 0.2, 0.3]} castShadow>
      <boxGeometry args={[0.2, 0.4, 0.6]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
  </group>
);

const ChairModel = ({ color }: { color: string }) => (
  <group>
    <mesh position={[0, -0.2, 0]} castShadow>
      <boxGeometry args={[0.8, 0.1, 0.8]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 0.4, -0.3]} castShadow>
      <boxGeometry args={[0.8, 0.7, 0.1]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[-0.35, 0, 0]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#888" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0.35, 0, 0]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#888" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[-0.35, 0, -0.35]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#888" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0.35, 0, -0.35]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#888" roughness={0.3} metalness={0.4} />
    </mesh>
  </group>
);

const TableModel = ({ color }: { color: string }) => (
  <group>
    <mesh position={[0, 0, 0]} castShadow>
      <boxGeometry args={[1.2, 0.1, 0.8]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[-0.5, -0.4, -0.3]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0.5, -0.4, -0.3]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[-0.5, -0.4, 0.3]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0.5, -0.4, 0.3]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
  </group>
);

const BedModel = ({ color }: { color: string }) => (
  <group>
    <mesh position={[0, -0.1, 0]} castShadow>
      <boxGeometry args={[2, 0.2, 1.5]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, -0.3, 0]} castShadow>
      <boxGeometry args={[2, 0.1, 1.5]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0, 0.1, -0.7]} castShadow>
      <boxGeometry args={[2, 0.4, 0.1]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 0.1, 0.7]} castShadow>
      <boxGeometry args={[2, 0.2, 0.1]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
  </group>
);

const LampModel = ({ color }: { color: string }) => (
  <group>
    <mesh position={[0, 0.8, 0]} castShadow>
      <coneGeometry args={[0.3, 0.5, 32]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 0.5, 0]}>
      <sphereGeometry args={[0.05, 32, 32]} />
      <meshStandardMaterial color="#FFF" emissive="#FFF" emissiveIntensity={0.5} />
    </mesh>
    <mesh position={[0, 0, 0]} castShadow>
      <cylinderGeometry args={[0.03, 0.03, 1]} />
      <meshStandardMaterial color="#111" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0, -0.5, 0]} castShadow>
      <cylinderGeometry args={[0.2, 0.2, 0.05]} />
      <meshStandardMaterial color="#333" roughness={0.3} metalness={0.4} />
    </mesh>
  </group>
);

const ModelComponent = ({ type, color }: { type: string; color: string }) => {
  switch (type) {
    case 'sofa':
      return <SofaModel color={color} />;
    case 'chair':
      return <ChairModel color={color} />;
    case 'table':
      return <TableModel color={color} />;
    case 'bed':
      return <BedModel color={color} />;
    case 'lamp':
      return <LampModel color={color} />;
    default:
      return null;
  }
};

const PlacementPoints: React.FC<PlacementPointsProps> = ({
  imageUrl,
  placementPoints,
  placedModels,
  furnitureModels,
  selectedColor,
  onAddPlacedModel,
  onAddPlacementPoint,
  onRemovePlacedModel
}) => {
  const [imageSize, setImageSize] = useState({ width: 0, height: 0 });
  const [isDraggingOver, setIsDraggingOver] = useState<string | null>(null);
  const [containerRef, setContainerRef] = useState<HTMLDivElement | null>(null);
  const [isAddingPoint, setIsAddingPoint] = useState(false);
  const [defaultModelType, setDefaultModelType] = useState<'sofa' | 'chair' | 'table' | 'bed' | 'lamp'>('sofa');
  const [modelScale, setModelScale] = useState<Record<string, number>>({});

  useEffect(() => {
    // Load the image to get its dimensions
    const img = new Image();
    img.onload = () => {
      setImageSize({
        width: img.width,
        height: img.height
      });
    };
    img.src = imageUrl;
  }, [imageUrl]);

  const handleDragOver = (e: React.DragEvent, pointId: string) => {
    e.preventDefault();
    setIsDraggingOver(pointId);
  };

  const handleDragLeave = () => {
    setIsDraggingOver(null);
  };

  const handleDrop = (e: React.DragEvent, point: PlacementPoint) => {
    e.preventDefault();
    setIsDraggingOver(null);
    
    try {
      const data = JSON.parse(e.dataTransfer.getData('application/json'));
      
      if (data.modelId && data.color) {
        // Check if model type matches point type
        const model = furnitureModels[data.modelId];
        if (model && model.type === point.type) {
          const newPlacedModel: PlacedModel = {
            id: Date.now().toString(),
            modelId: data.modelId,
            pointId: point.id,
            color: data.color // Use the color that was passed from the drag operation
          };
          
          onAddPlacedModel(newPlacedModel);
          
          // Initialize scale for this model
          setModelScale(prev => ({
            ...prev,
            [newPlacedModel.id]: 1.0
          }));
        }
      }
    } catch (error) {
      console.error('Error parsing drag data:', error);
    }
  };

  const handleImageClick = (e: React.MouseEvent) => {
    if (!isAddingPoint || !containerRef) return;

    const rect = containerRef.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Calculate percentage position within the image
    const percentX = (x / rect.width) * 100;
    const percentY = (y / rect.height) * 100;

    // Convert to image coordinates
    const pointX = (percentX / 100) * imageSize.width;
    const pointY = (percentY / 100) * imageSize.height;

    // Add a new placement point
    onAddPlacementPoint({
      x: pointX,
      y: pointY,
      type: defaultModelType,
      filled: false
    });

    // Exit adding mode
    setIsAddingPoint(false);
  };

  const handleZoomIn = (modelId: string) => {
    setModelScale(prev => ({
      ...prev,
      [modelId]: (prev[modelId] || 1) * 1.2
    }));
  };

  const handleZoomOut = (modelId: string) => {
    setModelScale(prev => ({
      ...prev,
      [modelId]: (prev[modelId] || 1) * 0.8
    }));
  };

  const getPlacementIcon = (type: string) => {
    switch (type) {
      case 'sofa':
        return <SquareDotIcon className="h-full w-full text-brand-purple" />;
      case 'chair':
        return <CircleIcon className="h-full w-full text-brand-blue" />;
      case 'table':
        return <SquareDotIcon className="h-full w-full text-brand-orange" />;
      case 'bed':
        return <SquareDotIcon className="h-full w-full text-brand-purple" />;
      case 'lamp':
        return <CircleDotIcon className="h-full w-full text-yellow-400" />;
      default:
        return <CircleDotIcon className="h-full w-full" />;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2 mb-2">
        <Button 
          size="sm" 
          variant={isAddingPoint ? "default" : "outline"} 
          onClick={() => setIsAddingPoint(!isAddingPoint)}
          className={isAddingPoint ? "bg-brand-purple" : ""}
        >
          <Plus className="w-4 h-4 mr-1" />
          {isAddingPoint ? "Click on image to place" : "Add placement point"}
        </Button>
        
        {isAddingPoint && (
          <div className="flex gap-2 items-center">
            <span className="text-sm text-gray-500">Type:</span>
            <select
              className="border rounded px-2 py-1 text-sm"
              value={defaultModelType}
              onChange={(e) => setDefaultModelType(e.target.value as any)}
            >
              <option value="sofa">Sofa</option>
              <option value="chair">Chair</option>
              <option value="table">Table</option>
              <option value="bed">Bed</option>
              <option value="lamp">Lamp</option>
            </select>
          </div>
        )}
      </div>
      
      <div 
        className={`relative inline-block ${isAddingPoint ? 'cursor-crosshair' : ''}`}
        ref={setContainerRef}
        onClick={isAddingPoint ? handleImageClick : undefined}
      >
        <img 
          src={imageUrl} 
          alt="Uploaded room" 
          className="max-w-full rounded-lg shadow-lg"
        />
        
        {placementPoints.map(point => {
          const placedModel = placedModels.find(model => model.pointId === point.id);
          const isActive = isDraggingOver === point.id;
          
          // Use percentage-based positioning for points
          return (
            <div
              key={point.id}
              className={`absolute w-8 h-8 ${placedModel ? 'opacity-0 pointer-events-none' : 'opacity-100'} 
                         ${isActive ? 'scale-125 z-30' : ''} transition-all duration-300`}
              style={{
                left: `${(point.x / imageSize.width) * 100}%`,
                top: `${(point.y / imageSize.height) * 100}%`,
                transform: 'translate(-50%, -50%)'
              }}
              onDragOver={(e) => handleDragOver(e, point.id)}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, point)}
            >
              {getPlacementIcon(point.type)}
            </div>
          );
        })}
        
        {placedModels.map(placedModel => {
          const point = placementPoints.find(p => p.id === placedModel.pointId);
          const model = furnitureModels[placedModel.modelId];
          const currentScale = modelScale[placedModel.id] || 1;
          
          if (!point || !model) return null;
          
          const baseModelSize = model.type === 'sofa' || model.type === 'bed' ? 160 :
                               model.type === 'table' ? 120 : 100;
          
          // Apply the zoom scale to the model size
          const modelSize = baseModelSize * currentScale;
          
          return (
            <div
              key={placedModel.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 animate-scale-in group"
              style={{
                left: `${(point.x / imageSize.width) * 100}%`,
                top: `${(point.y / imageSize.height) * 100}%`,
                width: `${modelSize}px`,
                height: `${modelSize}px`,
                zIndex: 20
              }}
            >
              <Canvas
                camera={{ position: [0, 0, 4], fov: 50 }}
                style={{ 
                  borderRadius: '0.5rem'
                }}
              >
                <ambientLight intensity={0.8} />
                <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1.5} />
                <pointLight position={[-10, -10, -10]} intensity={0.5} />
                <Environment preset="sunset" />
                
                <PresentationControls
                  global
                  rotation={[0, -Math.PI / 4, 0]}
                  polar={[-Math.PI / 4, Math.PI / 4]}
                  azimuth={[-Math.PI / 4, Math.PI / 4]}
                  config={{ mass: 1, tension: 170, friction: 26 }}
                >
                  <group position={[0, 0, 0]} scale={1}>
                    <ModelComponent type={model.type} color={placedModel.color} />
                  </group>
                </PresentationControls>
              </Canvas>
              
              {/* Control buttons for each placed model */}
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 flex bg-white/80 backdrop-blur-sm rounded-full p-1 shadow-md transition-all duration-300">
                <button
                  className="p-1 hover:bg-gray-200 rounded-full"
                  onClick={() => handleZoomIn(placedModel.id)}
                  title="Zoom in"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
                <button
                  className="p-1 hover:bg-gray-200 rounded-full"
                  onClick={() => handleZoomOut(placedModel.id)}
                  title="Zoom out"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <button
                  className="p-1 hover:bg-red-200 rounded-full"
                  onClick={() => onRemovePlacedModel(placedModel.id)}
                  title="Remove"
                >
                  <Trash className="w-4 h-4 text-red-500" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="text-center mt-2 text-sm text-gray-500">
        {isAddingPoint ? "Click on the image to place a new point" : "Drag furniture models onto placement points"}
      </div>
    </div>
  );
};

export default PlacementPoints;
