
import React, { useRef, useState, useCallback } from 'react';
import { Color } from '../types';
import { useToast } from '@/components/ui/use-toast';
import { rgbToHex } from '../utils/colorUtils';
import { Crosshair, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ImageEditorProps {
  imageUrl: string;
  onColorPick: (color: Color) => void;
  onRestart: () => void;
}

const ImageEditor: React.FC<ImageEditorProps> = ({ 
  imageUrl, 
  onColorPick,
  onRestart
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isPicking, setIsPicking] = useState(false);
  const [previewColor, setPreviewColor] = useState<Color | null>(null);
  const { toast } = useToast();

  const handleCanvasLoad = useCallback(() => {
    const canvas = canvasRef.current;
    const img = new Image();
    
    img.onload = () => {
      if (canvas) {
        const context = canvas.getContext('2d', { willReadFrequently: true });
        
        if (context) {
          // Set canvas size to fit the image (max of 100% width/height)
          const maxWidth = window.innerWidth * 0.8;
          const maxHeight = window.innerHeight * 0.6;
          
          let width = img.width;
          let height = img.height;
          
          if (width > maxWidth) {
            const ratio = maxWidth / width;
            width *= ratio;
            height *= ratio;
          }
          
          if (height > maxHeight) {
            const ratio = maxHeight / height;
            width *= ratio;
            height *= ratio;
          }
          
          canvas.width = width;
          canvas.height = height;
          
          // Draw image on canvas
          context.drawImage(img, 0, 0, width, height);
        }
      }
    };
    
    img.src = imageUrl;
  }, [imageUrl]);

  React.useEffect(() => {
    handleCanvasLoad();
  }, [handleCanvasLoad]);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isPicking) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const context = canvas.getContext('2d', { willReadFrequently: true });
    if (!context) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Get pixel color
    const imageData = context.getImageData(x, y, 1, 1);
    const data = imageData.data;
    
    const r = data[0];
    const g = data[1];
    const b = data[2];
    
    const hex = rgbToHex(r, g, b);
    
    setPreviewColor({ hex, rgb: { r, g, b } });
  }, [isPicking]);

  const handleCanvasClick = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const context = canvas.getContext('2d', { willReadFrequently: true });
    if (!context) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Get pixel color
    const imageData = context.getImageData(x, y, 1, 1);
    const data = imageData.data;
    
    const r = data[0];
    const g = data[1];
    const b = data[2];
    
    const hex = rgbToHex(r, g, b);
    
    const color = { hex, rgb: { r, g, b } };
    onColorPick(color);
    
    toast({
      title: "Color picked",
      description: `Selected color: ${hex}`,
    });
    
    setIsPicking(false);
  }, [onColorPick, toast]);

  return (
    <div className="flex flex-col items-center">
      <div className="relative inline-block mb-4">
        <canvas
          ref={canvasRef}
          className={`rounded-lg shadow-lg ${isPicking ? 'cursor-crosshair' : 'cursor-default'}`}
          onClick={isPicking ? handleCanvasClick : undefined}
          onMouseMove={handleMouseMove}
        />
        
        {isPicking && previewColor && (
          <div className="absolute bottom-4 right-4 p-2 bg-white rounded-lg shadow-lg flex items-center gap-2">
            <div 
              className="w-6 h-6 rounded-full" 
              style={{ backgroundColor: previewColor.hex }}
            />
            <span className="text-sm font-medium">{previewColor.hex}</span>
          </div>
        )}
      </div>
      
      <div className="flex flex-wrap gap-2 justify-center">
        <Button
          variant="outline"
          className={isPicking ? 'bg-brand-purple text-white' : ''}
          onClick={() => setIsPicking(!isPicking)}
        >
          <Crosshair className="w-4 h-4 mr-2" />
          {isPicking ? 'Click to pick a color' : 'Pick color from image'}
        </Button>
        
        <Button variant="outline" onClick={onRestart}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Upload new image
        </Button>
      </div>
    </div>
  );
};

export default ImageEditor;
