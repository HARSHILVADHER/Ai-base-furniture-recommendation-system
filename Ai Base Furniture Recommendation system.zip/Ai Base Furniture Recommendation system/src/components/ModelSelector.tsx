
import React from 'react';
import { FurnitureModel } from '../types';
import ThreeDViewer from './ThreeDViewer';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SofaIcon, ArmchairIcon, TableIcon, BedIcon, LampIcon } from 'lucide-react';

interface ModelSelectorProps {
  models: FurnitureModel[];
  selectedColor: string;
  onDragModel: (model: FurnitureModel) => void;
}

const ModelSelector: React.FC<ModelSelectorProps> = ({ 
  models, 
  selectedColor,
  onDragModel
}) => {
  const categories = [
    { id: 'all', label: 'All', icon: null },
    { id: 'sofa', label: 'Sofa', icon: <SofaIcon className="w-4 h-4" /> },
    { id: 'chair', label: 'Chair', icon: <ArmchairIcon className="w-4 h-4" /> },
    { id: 'table', label: 'Table', icon: <TableIcon className="w-4 h-4" /> },
    { id: 'bed', label: 'Bed', icon: <BedIcon className="w-4 h-4" /> },
    { id: 'lamp', label: 'Lamp', icon: <LampIcon className="w-4 h-4" /> }
  ];
  
  const getModelsByCategory = (category: string) => {
    if (category === 'all') return models;
    return models.filter(model => model.type === category);
  };

  return (
    <div className="bg-white rounded-lg shadow-md">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="text-lg font-medium">3D Preview</h2>
        
        <div className="flex space-x-2">
          {categories.slice(1).map(category => (
            <button
              key={category.id}
              className={`px-3 py-2 rounded-md text-sm flex items-center gap-1
                         ${selectedColor === category.id 
                             ? 'bg-brand-purple text-white' 
                             : 'bg-gray-100 hover:bg-gray-200'}`}
            >
              {category.icon} {category.label}
            </button>
          ))}
        </div>
      </div>
      
      <div className="p-4">
        <Tabs defaultValue="all" className="mb-4">
          <TabsList className="grid grid-cols-6 mb-4">
            {categories.map(category => (
              <TabsTrigger 
                key={category.id}
                value={category.id} 
                className="text-xs flex items-center justify-center gap-1"
              >
                {category.icon}
                {category.label}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {categories.map(category => (
            <TabsContent key={category.id} value={category.id}>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                {getModelsByCategory(category.id).length > 0 ? (
                  getModelsByCategory(category.id).map(model => (
                    <ThreeDViewer
                      key={model.id}
                      model={model}
                      color={selectedColor}
                      onDragModel={onDragModel}
                    />
                  ))
                ) : (
                  <p className="col-span-3 text-center text-gray-500 py-4">
                    No models available in this category.
                  </p>
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>
        
        <div className="text-center mt-4 py-2 bg-gray-100 rounded-md text-sm text-gray-600">
          Drag model to place onto points
        </div>
      </div>
    </div>
  );
};

export default ModelSelector;
