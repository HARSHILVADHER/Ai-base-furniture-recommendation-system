
import React from 'react';
import { Color } from '../types';
import { ChevronRight, CheckIcon } from 'lucide-react';

interface ColorPaletteProps {
  colors: Color[];
  selectedColor: Color | null;
  onSelectColor: (color: Color) => void;
}

const ColorPalette: React.FC<ColorPaletteProps> = ({ 
  colors, 
  selectedColor, 
  onSelectColor 
}) => {
  if (colors.length === 0) {
    return (
      <div className="flex flex-col gap-2 p-4 bg-white rounded-lg shadow-md">
        <p className="text-sm text-gray-500 italic">
          Upload an image to extract colors
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4 p-4 bg-white rounded-lg shadow-md">
      <div className="flex items-center">
        <h3 className="text-lg font-medium">Color Palette</h3>
        <ChevronRight className="w-4 h-4 ml-2 text-gray-400" />
        <div 
          className="w-6 h-6 rounded-full ml-2" 
          style={{ 
            backgroundColor: selectedColor ? selectedColor.hex : 'transparent',
            border: selectedColor ? 'none' : '2px dashed #e2e8f0'
          }}
        />
      </div>
      
      <div className="flex flex-wrap gap-3 justify-center">
        {colors.map((color, index) => (
          <button
            key={index}
            className={`color-swatch ${selectedColor?.hex === color.hex ? 'active' : ''}`}
            style={{ backgroundColor: color.hex }}
            onClick={() => onSelectColor(color)}
            aria-label={`Select color ${color.hex}`}
          >
            {selectedColor?.hex === color.hex && (
              <span className="absolute inset-0 flex items-center justify-center">
                <CheckIcon className="w-4 h-4 text-white drop-shadow-lg" />
              </span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ColorPalette;
