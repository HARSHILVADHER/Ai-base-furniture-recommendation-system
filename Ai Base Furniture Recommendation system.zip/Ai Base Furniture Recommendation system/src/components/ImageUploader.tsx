
import React, { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Upload, Image as ImageIcon } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface ImageUploaderProps {
  onImageUpload: (file: File, imageUrl: string) => void;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload }) => {
  const [isDragging, setIsDragging] = useState(false);
  const { toast } = useToast();

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = e.dataTransfer.files;
    
    if (files.length > 0) {
      const file = files[0];
      
      if (file.type.match('image.*')) {
        const reader = new FileReader();
        
        reader.onload = (event) => {
          if (event.target && typeof event.target.result === 'string') {
            onImageUpload(file, event.target.result);
          }
        };
        
        reader.readAsDataURL(file);
      } else {
        toast({
          title: "Unsupported file type",
          description: "Please upload an image file (JPG, PNG, etc.)",
          variant: "destructive"
        });
      }
    }
  }, [onImageUpload, toast]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    
    if (files && files.length > 0) {
      const file = files[0];
      
      if (file.type.match('image.*')) {
        const reader = new FileReader();
        
        reader.onload = (event) => {
          if (event.target && typeof event.target.result === 'string') {
            onImageUpload(file, event.target.result);
          }
        };
        
        reader.readAsDataURL(file);
      } else {
        toast({
          title: "Unsupported file type",
          description: "Please upload an image file (JPG, PNG, etc.)",
          variant: "destructive"
        });
      }
    }
  }, [onImageUpload, toast]);

  return (
    <div 
      className={`dropzone ${isDragging ? 'active' : ''}`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <div className="flex flex-col items-center justify-center gap-4">
        <div className="p-4 rounded-full bg-brand-purple/10">
          <Upload className="w-10 h-10 text-brand-purple" />
        </div>
        <div className="text-center">
          <h3 className="text-lg font-medium">Drag & Drop your image here</h3>
          <p className="text-sm text-gray-500">or click to browse your files</p>
        </div>
        <div className="flex items-center gap-3">
          <Button 
            variant="outline" 
            onClick={() => document.getElementById('file-upload')?.click()}
          >
            <ImageIcon className="w-4 h-4 mr-2" />
            Select Image
          </Button>
        </div>
        <input
          id="file-upload"
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileSelect}
        />
      </div>
    </div>
  );
};

export default ImageUploader;
