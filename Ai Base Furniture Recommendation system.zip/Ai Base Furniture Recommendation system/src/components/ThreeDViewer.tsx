
import React, { useRef, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { PresentationControls, Environment } from '@react-three/drei';
import { FurnitureModel } from '../types';
import { MoveIcon } from 'lucide-react';
import * as THREE from 'three';

interface ThreeDViewerProps {
  model: FurnitureModel;
  color: string;
  onDragModel: (model: FurnitureModel) => void;
}

// Simple 3D model components
const SofaModel = ({ color }: { color: string }) => (
  <group>
    <mesh position={[0, -0.2, 0]} castShadow>
      <boxGeometry args={[2, 0.4, 1]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 0.4, -0.5]} castShadow>
      <boxGeometry args={[2, 0.8, 0.2]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[-0.9, 0.2, 0.3]} castShadow>
      <boxGeometry args={[0.2, 0.4, 0.6]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0.9, 0.2, 0.3]} castShadow>
      <boxGeometry args={[0.2, 0.4, 0.6]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
  </group>
);

const ChairModel = ({ color }: { color: string }) => (
  <group>
    <mesh position={[0, -0.2, 0]} castShadow>
      <boxGeometry args={[0.8, 0.1, 0.8]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 0.4, -0.3]} castShadow>
      <boxGeometry args={[0.8, 0.7, 0.1]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[-0.35, 0, 0]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#888" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0.35, 0, 0]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#888" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[-0.35, 0, -0.35]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#888" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0.35, 0, -0.35]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#888" roughness={0.3} metalness={0.4} />
    </mesh>
  </group>
);

const TableModel = ({ color }: { color: string }) => (
  <group>
    <mesh position={[0, 0, 0]} castShadow>
      <boxGeometry args={[1.2, 0.1, 0.8]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[-0.5, -0.4, -0.3]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0.5, -0.4, -0.3]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[-0.5, -0.4, 0.3]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0.5, -0.4, 0.3]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
  </group>
);

const BedModel = ({ color }: { color: string }) => (
  <group>
    <mesh position={[0, -0.1, 0]} castShadow>
      <boxGeometry args={[2, 0.2, 1.5]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, -0.3, 0]} castShadow>
      <boxGeometry args={[2, 0.1, 1.5]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0, 0.1, -0.7]} castShadow>
      <boxGeometry args={[2, 0.4, 0.1]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 0.1, 0.7]} castShadow>
      <boxGeometry args={[2, 0.2, 0.1]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
  </group>
);

const LampModel = ({ color }: { color: string }) => (
  <group>
    <mesh position={[0, 0.8, 0]} castShadow>
      <coneGeometry args={[0.3, 0.5, 32]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 0.5, 0]}>
      <sphereGeometry args={[0.05, 32, 32]} />
      <meshStandardMaterial color="#FFF" emissive="#FFF" emissiveIntensity={0.5} />
    </mesh>
    <mesh position={[0, 0, 0]} castShadow>
      <cylinderGeometry args={[0.03, 0.03, 1]} />
      <meshStandardMaterial color="#111" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0, -0.5, 0]} castShadow>
      <cylinderGeometry args={[0.2, 0.2, 0.05]} />
      <meshStandardMaterial color="#333" roughness={0.3} metalness={0.4} />
    </mesh>
  </group>
);

const ModelComponent = ({ type, color }: { type: string; color: string }) => {
  switch (type) {
    case 'sofa':
      return <SofaModel color={color} />;
    case 'chair':
      return <ChairModel color={color} />;
    case 'table':
      return <TableModel color={color} />;
    case 'bed':
      return <BedModel color={color} />;
    case 'lamp':
      return <LampModel color={color} />;
    default:
      return null;
  }
};

const ThreeDViewer: React.FC<ThreeDViewerProps> = ({ 
  model, 
  color, 
  onDragModel 
}) => {
  const groupRef = useRef<THREE.Group>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleDragStart = (e: React.DragEvent) => {
    setIsDragging(true);
    // Set the drag data - make sure we're explicitly passing the color
    e.dataTransfer.setData('application/json', JSON.stringify({
      modelId: model.id,
      color: color // Explicitly pass the selected color
    }));
    
    // Call the onDragModel callback
    onDragModel(model);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
  };

  return (
    <div className="group relative flex flex-col items-center">
      <div 
        ref={containerRef}
        className="p-4 w-48 h-48 relative cursor-grab active:cursor-grabbing transition-transform hover:scale-105"
        draggable
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
      >
        <Canvas
          camera={{ position: [0, 0, 4], fov: 50 }}
          style={{ 
            background: isDragging ? 'rgba(139, 92, 246, 0.1)' : 'transparent',
            borderRadius: '0.5rem'
          }}
        >
          <ambientLight intensity={0.8} />
          <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1.5} />
          <pointLight position={[-10, -10, -10]} intensity={0.5} />
          <Environment preset="sunset" />
          
          <PresentationControls
            global
            rotation={[0, -Math.PI / 4, 0]}
            polar={[-Math.PI / 4, Math.PI / 4]}
            azimuth={[-Math.PI / 4, Math.PI / 4]}
            config={{ mass: 1, tension: 170, friction: 26 }}
          >
            <group ref={groupRef} position={[0, 0, 0]} scale={1}>
              <ModelComponent type={model.type} color={color} />
            </group>
          </PresentationControls>
        </Canvas>
      </div>
      
      <div className="mt-2 text-center">
        <p className="font-medium">{model.name}</p>
        <div className="flex items-center justify-center mt-1 text-sm text-gray-500">
          <MoveIcon className="w-4 h-4 mr-1 text-brand-purple drag-handle" />
          <span className="text-xs">Drag to place on image</span>
        </div>
      </div>
    </div>
  );
};

export default ThreeDViewer;
