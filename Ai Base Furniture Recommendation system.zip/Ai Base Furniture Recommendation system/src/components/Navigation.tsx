
import React from 'react';
import { Link } from 'react-router-dom';
import { NavigationMenu, NavigationMenuContent, NavigationMenuItem, NavigationMenuLink, NavigationMenuList, NavigationMenuTrigger } from '@/components/ui/navigation-menu';
import { cn } from '@/lib/utils';
import { BookOpen, PlusSquare } from 'lucide-react';

const Navigation: React.FC = () => {
  return (
    <div className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <NavigationMenu>
          <NavigationMenuList>
            <NavigationMenuItem>
              <Link to="/" className="flex items-center mr-6 space-x-2">
                <span className="hidden sm:inline-block font-bold">Room Designer</span>
              </Link>
            </NavigationMenuItem>
            
            <NavigationMenuItem>
              <Link to="/how-it-works" className="group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none">
                <BookOpen className="mr-2 h-4 w-4" />
                <span>How It Works</span>
              </Link>
            </NavigationMenuItem>
            
            <NavigationMenuItem>
              <Link to="/create-room" className="group inline-flex h-10 w-max items-center justify-center rounded-md bg-brand-purple text-white px-4 py-2 text-sm font-medium transition-colors hover:bg-brand-purple/90 focus:outline-none">
                <PlusSquare className="mr-2 h-4 w-4" />
                <span>Create</span>
              </Link>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>
      </div>
    </div>
  );
};

export default Navigation;
