
import React from 'react';

// Sofa model
export const Sofa: React.FC<{ color: string }> = ({ color }) => (
  <group>
    <mesh position={[0, 0.4, 0]} castShadow>
      <boxGeometry args={[2, 0.4, 1]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 0.8, -0.5]} castShadow>
      <boxGeometry args={[2, 0.8, 0.2]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[-0.9, 0.6, 0.3]} castShadow>
      <boxGeometry args={[0.2, 0.4, 0.6]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0.9, 0.6, 0.3]} castShadow>
      <boxGeometry args={[0.2, 0.4, 0.6]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
  </group>
);

// Chair model
export const Chair: React.FC<{ color: string }> = ({ color }) => (
  <group>
    <mesh position={[0, 0.3, 0]} castShadow>
      <boxGeometry args={[0.8, 0.1, 0.8]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 0.8, -0.3]} castShadow>
      <boxGeometry args={[0.8, 0.7, 0.1]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[-0.35, 0.1, 0]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.5]} />
      <meshStandardMaterial color="#888" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0.35, 0.1, 0]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.5]} />
      <meshStandardMaterial color="#888" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[-0.35, 0.1, -0.35]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.5]} />
      <meshStandardMaterial color="#888" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0.35, 0.1, -0.35]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.5]} />
      <meshStandardMaterial color="#888" roughness={0.3} metalness={0.4} />
    </mesh>
  </group>
);

// Table model
export const Table: React.FC<{ color: string }> = ({ color }) => (
  <group>
    <mesh position={[0, 0.7, 0]} castShadow>
      <boxGeometry args={[1.2, 0.1, 0.8]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[-0.5, 0.3, -0.3]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0.5, 0.3, -0.3]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[-0.5, 0.3, 0.3]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0.5, 0.3, 0.3]} castShadow>
      <cylinderGeometry args={[0.05, 0.05, 0.8]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
  </group>
);

// Bed model
export const Bed: React.FC<{ color: string }> = ({ color }) => (
  <group>
    <mesh position={[0, 0.3, 0]} castShadow>
      <boxGeometry args={[2, 0.2, 1.5]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 0.1, 0]} castShadow>
      <boxGeometry args={[2, 0.1, 1.5]} />
      <meshStandardMaterial color="#444" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0, 0.5, -0.7]} castShadow>
      <boxGeometry args={[2, 0.4, 0.1]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 0.4, 0.7]} castShadow>
      <boxGeometry args={[2, 0.2, 0.1]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
  </group>
);

// Lamp model
export const Lamp: React.FC<{ color: string }> = ({ color }) => (
  <group>
    <mesh position={[0, 1.5, 0]} castShadow>
      <coneGeometry args={[0.3, 0.5, 32]} />
      <meshStandardMaterial color={color} roughness={0.3} metalness={0.2} />
    </mesh>
    <mesh position={[0, 1.2, 0]}>
      <sphereGeometry args={[0.05, 32, 32]} />
      <meshStandardMaterial color="#FFF" emissive="#FFF" emissiveIntensity={0.5} />
    </mesh>
    <mesh position={[0, 0.7, 0]} castShadow>
      <cylinderGeometry args={[0.03, 0.03, 1]} />
      <meshStandardMaterial color="#111" roughness={0.3} metalness={0.4} />
    </mesh>
    <mesh position={[0, 0.2, 0]} castShadow>
      <cylinderGeometry args={[0.2, 0.2, 0.05]} />
      <meshStandardMaterial color="#333" roughness={0.3} metalness={0.4} />
    </mesh>
  </group>
);
