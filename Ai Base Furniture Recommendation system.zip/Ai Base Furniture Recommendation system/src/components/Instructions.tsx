
import React from 'react';
import { Upload, Palette, MousePointer, MoveHorizontal } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

const Instructions: React.FC = () => {
  const steps = [
    {
      icon: <Upload className="w-5 h-5" />,
      title: "Upload Your Space",
      description: "Start by uploading a photo of your room or space"
    },
    {
      icon: <Palette className="w-5 h-5" />,
      title: "Choose Colors",
      description: "Select from extracted colors or pick directly from your image"
    },
    {
      icon: <MousePointer className="w-5 h-5" />,
      title: "Select Furniture",
      description: "Browse furniture models and pick the ones you like"
    },
    {
      icon: <MoveHorizontal className="w-5 h-5" />,
      title: "Drag & Drop",
      description: "Drag furniture models to placement points on your image"
    },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h2 className="text-lg font-medium mb-4">How It Works</h2>
      
      <div className="space-y-4">
        {steps.map((step, index) => (
          <React.Fragment key={index}>
            <div className="flex items-start">
              <div className="flex-shrink-0 bg-brand-purple/10 p-2 rounded-full mr-3">
                {step.icon}
              </div>
              <div>
                <h3 className="font-medium">{step.title}</h3>
                <p className="text-sm text-gray-500">{step.description}</p>
              </div>
            </div>
            {index < steps.length - 1 && (
              <Separator className="my-2" />
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

export default Instructions;
