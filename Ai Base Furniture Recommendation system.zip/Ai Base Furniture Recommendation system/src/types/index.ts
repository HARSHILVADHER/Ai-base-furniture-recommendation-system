
export interface Color {
  id?: string;
  name?: string;
  hex: string;
  rgb: {
    r: number;
    g: number;
    b: number;
  };
}

export interface FurnitureModel {
  id: string;
  name: string;
  type: 'sofa' | 'chair' | 'table' | 'bed' | 'lamp';
  previewImage: string;
}

export interface PlacementPoint {
  id: string;
  x: number;
  y: number;
  type: 'sofa' | 'chair' | 'table' | 'bed' | 'lamp';
  filled: boolean;
  modelId?: string;
}

export interface PlacedModel {
  id: string;
  modelId: string;
  pointId: string;
  color: string;
}
